# MISSIONARIES AND CANNIBALS

A Pen created on CodePen.

Original URL: [https://codepen.io/shruthi-sk-the-builder/pen/XJWvMjb](https://codepen.io/shruthi-sk-the-builder/pen/XJWvMjb).

